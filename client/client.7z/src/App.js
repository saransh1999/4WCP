import Login from "./components/Login";
import axios from "axios";
import { useState , useEffect } from 'react';
import UserDashboard from "./components/UserDashboard";




function App() {
  const [loginStatus, setLoginStatus] = useState(false);
  const [acessToken, setAcessToken] = useState("");
  const handleLoginSubmit = async({username,password}) =>{
    // console.log(username,password);
    try{
      const response = await axios.post("http://localhost:5000/api/login", {username,password});
      setLoginStatus(true);
      setAcessToken(response.data.accessToken);
    }catch(err){
      console.log(err)
    }
  }
  useEffect(()=>{
    console.log(acessToken);
  },[acessToken])

  return (
    <div>
      {loginStatus ? (<UserDashboard/>) : (<Login onLoginSubmit = {handleLoginSubmit}/>)}
    </div>
  );
}

export default App;
